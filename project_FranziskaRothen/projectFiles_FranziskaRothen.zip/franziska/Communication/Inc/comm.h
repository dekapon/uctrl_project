/*
 * comm.h
 *
 *  Created on: Dec 20, 2021
 *      Author: Franziska Rothen
 */

#ifndef INC_COMM_H_
#define INC_COMM_H_

void sendMessage(char *messageToSend);

#endif /* INC_COMM_H_ */
