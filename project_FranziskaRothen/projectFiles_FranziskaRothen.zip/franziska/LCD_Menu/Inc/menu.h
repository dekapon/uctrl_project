/*
 * menu.h
 *
 *  Created on: Dec 10, 2021
 *      Author: Franziska Rothen
 */

#ifndef INC_MENU_H_
#define INC_MENU_H_

void welcome_display(void);
void menu1_display(void);
void menu2_display(void);
char menu3_display(int weight);
void menu4_display(int value);
void menu5_display(void);

#endif /* INC_MENU_H_ */
